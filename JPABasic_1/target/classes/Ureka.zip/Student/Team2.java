package Ureka.Student;

public class Team2 {
    public static String[] members = {"신혜원", "신수현", "이종규", "정동현", "한세영"};
}