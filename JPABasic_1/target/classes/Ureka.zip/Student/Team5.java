package Ureka.Student;

public class Team5 {
    public static String[] members = {"이도연", "박기환", "이희용", "장승범", "정현경", "최웅렬"};
}