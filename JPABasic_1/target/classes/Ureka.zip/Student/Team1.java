package Ureka.Student;

public class Team1 {
    public static String[] members = {"변지민", "이재윤", "정유민", "하령경"};
}