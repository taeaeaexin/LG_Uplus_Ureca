package Ureka.Student;

public class Team4 {
    public static String[] members = {"문태신", "서보인", "신승우", "임민서", "정성빈", "한윤수"};
}