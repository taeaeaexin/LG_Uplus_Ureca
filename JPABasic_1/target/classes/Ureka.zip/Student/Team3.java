package Ureka.Student;

public class Team3 {
    public static String[] members = {"김시헌", "손민혁", "이본규", "장현서", "전다인", "허승현"};
}